d={}
for i in range(int(input())):
    d[input()]=1

for i,j in d.items():
    print(i)


'''
= testcase:1
4
david ECE 193.4 chennai
david ECE 194.4 Coimbatore
david ECE 194.4 Coimbatore
carl CSE 197.4 Coimbatore
david ECE 193.4 chennai
david ECE 194.4 Coimbatore
carl CSE 197.4 Coimbatore
'''
